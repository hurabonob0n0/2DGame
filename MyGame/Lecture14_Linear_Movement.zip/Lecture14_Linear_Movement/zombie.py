import random
import math
import game_framework
import game_world

from pico2d import *

from arrow import Arrow

# zombie Run Speed
PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
RUN_SPEED_KMPH = 25.0  # Km / Hour
RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

# zombie Action Speed
TIME_PER_ACTION = 0.5
ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
FRAMES_PER_ACTION = 10.0

animation_names = ['Walk']

import random
import math
import game_framework
import game_world

from pico2d import *

from arrow import Arrow

# ... (좀비 속도 관련 변수들은 그대로 둡니다) ...

animation_names = ['Walk']


class Zombie:
    images = None

    def load_images(self):
        if Zombie.images == None:
            Zombie.images = {}
            for name in animation_names:
                Zombie.images[name] = [load_image("./zombie/" + name + " (%d)" % i + ".png") for i in range(1, 11)]

    # 1. __init__ 수정
    def __init__(self):
        self.x, self.y = 1280 // 2, 1024 // 2
        self.load_images()
        self.frame = random.randint(0, 9)
        self.face_dir = random.choice([-1, 1])  # (draw에서 사용되진 않음)

        self.arrow = Arrow()
        game_world.add_object(self.arrow, 2)

        # --- 💖 하트 경로를 위한 변수 추가 ---
        self.heart_t = 0.0  # 하트 방정식의 t (0 ~ 2*pi)
        self.heart_scale = 15  # 하트 크기 (turtle 예제에서 가져옴)
        self.heart_center_x, self.heart_center_y = self.x, self.y  # 하트의 중심
        self.heart_steps = 100.0  # 하트를 몇 개의 점으로 나눌지 (100.0으로 나눠야 함)
        # --- 💖 ---

        # 화살표(목표)를 하트 경로의 첫 번째 지점으로 설정
        next_x, next_y = self.get_next_heart_point()
        self.arrow.x, self.arrow.y = next_x, next_y

        # 기존 선형 보간(Lerp) 변수들
        self.t = 0.0
        self.sx, self.sy = self.x, self.y
        self.distance = math.sqrt((self.arrow.x - self.x) ** 2 + (self.arrow.y - self.y) ** 2)
        if self.distance == 0: self.distance = 0.01  # 0으로 나누기 방지

    # 2. 💖 하트 경로 계산 메서드 추가
    def get_next_heart_point(self):
        """ 하트 방정식에 따라 다음 목표 지점을 계산하고 반환합니다. """

        # turtle 예제의 하트 방정식
        t_rad = self.heart_t
        heart_x = 16 * (math.sin(t_rad) ** 3)
        heart_y = 13 * math.cos(t_rad) - 5 * math.cos(2 * t_rad) - 2 * math.cos(3 * t_rad) - math.cos(4 * t_rad)

        # 다음 t 값 계산
        self.heart_t += (2 * math.pi) / self.heart_steps
        if self.heart_t > 2 * math.pi:  # 한 바퀴 돌면 초기화
            self.heart_t -= 2 * math.pi

        # 최종 좌표 반환 (중심 + 스케일 적용)
        final_x = self.heart_center_x + heart_x * self.heart_scale
        final_y = self.heart_center_y + heart_y * self.heart_scale
        return final_x, final_y

    def get_bb(self):
        return self.x - 50, self.y - 50, self.x + 50, self.y + 50

    # 3. update 메서드 수정
    def update(self):
        self.frame = (self.frame + FRAMES_PER_ACTION * ACTION_PER_TIME * game_framework.frame_time) % FRAMES_PER_ACTION

        if self.t < 1.0:
            # 목표 지점(self.arrow)으로 이동
            self.t += RUN_SPEED_PPS * game_framework.frame_time / self.distance
            self.x = self.sx * (1.0 - self.t) + (self.arrow.x * self.t)
            self.y = self.sy * (1.0 - self.t) + (self.arrow.y * self.t)
        else:
            # 목표 지점에 도달했을 때
            self.x, self.y = self.arrow.x, self.arrow.y  # 위치 고정
            self.t = 0.0  # 이동 타이머 초기화

            # --- 💖 수정된 부분 ---
            # self.arrow.reset_position() 대신, 하트의 다음 지점을 받아옴
            next_x, next_y = self.get_next_heart_point()
            self.arrow.x, self.arrow.y = next_x, next_y
            # --- 💖 ---

            # 새 목표 지점까지의 설정
            self.sx, self.sy = self.x, self.y
            self.distance = math.sqrt((self.arrow.x - self.x) ** 2 + (self.arrow.y - self.y) ** 2)
            if self.distance == 0: self.distance = 0.01  # 0으로 나누기 방지

    # (draw, handle_event, handle_collision은 수정할 필요 없음)
    def draw(self):
        if self.x > self.arrow.x:  # 화살표(목표) 위치에 따라 좌우 반전
            Zombie.images['Walk'][int(self.frame)].composite_draw(0, 'h', self.x, self.y, 100, 100)
        else:
            Zombie.images['Walk'][int(self.frame)].draw(self.x, self.y, 100, 100)
        draw_rectangle(*self.get_bb())

    def handle_event(self, event):
        pass

    def handle_collision(self, group, other):
        pass